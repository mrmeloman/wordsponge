# Word Sponge

Word Sponge is a Chrome and Firefox extension that helps you learn a new language by replacing words on web pages with their translations. Simply download the extension, choose the language you want to learn, and start browsing the web!

## Features

- Easy installation and setup
- Choose from a variety of languages to learn
- Replace words on any web page with their translations
- Click on translated words to switch back to the original word
- Add your own words by hand or upload a word list file (.txt, .csv, .tsv or .json)
- Works fully offline with your own words by default; downloading word lists from thewordsponge.com is an opt-in that refreshes once a day
- Only replaces words in regular text, not in attributes such as classes or data tags
- Does not replace words inside `<a>` tags or `<input>` tags
- Uses local storage to store the words list, avoiding unnecessary requests to the server
- Follows strict privacy and security guidelines and policies of the Chrome Web Store
- Works in Chrome (Manifest V3, Chrome 121 or newer) and Firefox (140 or newer) from the same code

## Installation Now

1. Download the wordsponge.zip file.
2. Extract the contents of the zip file to a folder on your computer.
3. Open Google Chrome and navigate to the extensions page by typing chrome://extensions into the address bar.
4. Enable Developer mode by clicking the toggle switch in the top-right corner of the page.
5. Click on the "Load unpacked" button in the top-left corner of the page.
6. Navigate to the folder where you extracted the zip file, and select it.
7. Click on the "Select Folder" button to load the extension.

### Firefox

1. Download the wordsponge.zip file.
2. Open Firefox and navigate to about:debugging#/runtime/this-firefox.
3. Click "Load Temporary Add-on..." and select the zip file (or the manifest.json from the extracted folder).
4. A temporary add-on is removed when Firefox closes. To keep it, sign the zip through [addons.mozilla.org](https://addons.mozilla.org/developers/) and install the signed file.

## Installation

1. Go to the [Chrome Web Store](https://chromewebstore.google.com/detail/word-sponge/kiphhbngjiidccgcebflhlmmabighbem) page for Word Sponge.
2. Click on the "Add to Chrome" button to add the extension to your browser.
3. Once installed, click on the Word Sponge icon in the top-right corner of your browser to open the options page.
4. Choose the language you want to learn from the dropdown menu, and click on "Save" to update your preferences.

That's it! You're now ready to start browsing the web and learning a new language.

## Usage

- Navigate to any web page in your browser.
- Any words on the page that match the words list for your chosen language will be replaced with their translations.
- Click on a translated word to switch back to the original word.
- Use the toggle in the extension popup to turn Word Sponge off for the current site.

## Your Own Words

Open the extension's settings (the "Settings" link in the popup, or the add-on's options page) to manage your own word list. By default the extension is fully local: it never contacts thewordsponge.com and uses only the words you add here. Your words are kept separately from any downloaded list and take priority over it, so they survive the daily update.

- Type words directly into the text box, one per line, as `word: translation`, and click "Save".
- Or upload a file. Text files (.txt, .csv, .tsv) take one pair per line separated by a colon, tab, comma or semicolon; lines starting with `#` are ignored. JSON files take either an object such as `{"cat": "gato"}` or an array of `["cat", "gato"]` pairs. Uploaded words are added to the list in the text box.
- To use the ready-made lists from thewordsponge.com instead, tick "Download word lists from thewordsponge.com" in settings. The browser then asks for permission to access that site; untick it to go back to local-only mode.

## Contributing

If you'd like to contribute to Word Sponge, please fork the repository and submit a pull request. All contributions are welcome, including bug fixes, feature requests, and translations for additional languages. Please note that by submitting a contribution, you agree to license your contribution for free to the creators and under any additional licenses we add to this project in the future.

## Forking Your Own

If you'd like to fork your own, you can do so easily by forking this repository. You could, for example, add word lists directly into the extension.
My version of the extension checks for updates to the word list every 24 hours from [thewordsponge.com](https://thewordsponge.com), but you could host your
own site or use a different method to update the word list.

## How to Change Language

1. Install the extension and enable downloads in its settings
2. Go to "thewordsponge.com" and click a new language
3. Click the "confirm" button too.
